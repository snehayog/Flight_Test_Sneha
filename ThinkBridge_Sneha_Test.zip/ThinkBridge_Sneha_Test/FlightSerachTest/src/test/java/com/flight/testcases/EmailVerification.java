
package com.flight.testcases;



import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.flight.base.TestBase;
import com.flight.pages.EmailPage;
import com.flight.pages.SignUpPage;
import com.flight.utilities.WaitHelper;



public class EmailVerification {
	@Test
	public void emailRecievedTest() {
		
		
		try {
			WebDriver driver=TestBase.initializeBrowser("chrome","jabaurl");
			SignUpPage signUpPage=new SignUpPage(driver);
			EmailPage emailpage=new EmailPage(driver);
			WaitHelper wait=new WaitHelper(driver);
			signUpPage.signUp("FullName", "OrganizationName", "Email");
			wait.pause(15000);
			emailpage.createEmailAccount("CreateEmail_mail");
			wait.pause(15000);
			emailpage.refreshPage();
			emailpage.getEmails();
			System.out.println("Verify Email is Recieved or Not");
			emailpage.verifyEmailRecived();
			TestBase.closebrowser();	 

		}
		catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			e.printStackTrace();
		}

	}}
