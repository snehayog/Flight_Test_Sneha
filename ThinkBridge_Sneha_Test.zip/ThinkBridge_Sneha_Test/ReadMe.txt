1)Install or make sure Chrome version Version 92.0.4515.159 is installed on your system

2)Make sure java is installed in your system.

3)Download maven from "https://maven.apache.org/download.cgi" and set the environment variable "Maven_Home" 
  also copy the maven bin path into path location in environment variable

3)Locate and open 'FlightTest' project in Eclipse

4).Setting webdriver executable path"
 i)Copy Chrome driver location from chrome driver folder
 ii)open TestBase.java and update current chrome webdriver location in executable path.

5)Makesure SignupEmail and CreateEmail should be same to check the inbox. 

6)For executing test go to src\test\java\com.flight.qa.testcases
and run SignupPageTest.java