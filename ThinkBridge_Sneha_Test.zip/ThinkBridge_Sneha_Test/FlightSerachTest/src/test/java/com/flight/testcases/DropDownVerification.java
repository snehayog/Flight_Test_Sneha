
package com.flight.testcases;
import java.util.Arrays;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.flight.base.TestBase;
import com.flight.pages.SignUpPage;




public class DropDownVerification  {
	
	
	
	@Test
	public void dropdownListTest() {
		
		try {
			WebDriver driver=TestBase.initializeBrowser("chrome","jabaurl");
			SignUpPage signUpPage=new SignUpPage(driver);
			List<String> actualValues=signUpPage.getDropDownList();
			List<String> expectedValues=Arrays.asList("English","Dutch");
			Assert.assertEquals(actualValues, expectedValues, "Languages Successfully verified");
			TestBase.closebrowser();

		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			e.printStackTrace();
		}




	}

}
