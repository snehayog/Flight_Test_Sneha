
package com.flight.base;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class TestBase {
	
	public static WebDriver driver;
	public static Properties config;
	public static FileInputStream fis;
	
	
	
	public static WebDriver initializeBrowser(String browserName,String url) throws IOException {

		config=new Properties();
		fis=new FileInputStream("C:\\salunsx\\eclipse-workspace\\FlightSerachTest\\src\\test\\resources\\properties\\config.properties");
		config.load(fis);

		browserName=config.getProperty("browser");
		url=config.getProperty("jabaurl");

		if(browserName.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "C:\\salunsx\\eclipse-workspace\\FlightSerachTest\\src\\test\\resources\\drivers\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.get(url);
			
		}	
		else if(browserName.equalsIgnoreCase("internetexplorer"))
		{
			System.setProperty("webdriver.ie.driver", "C:\\salunsx\\eclipse-workspace\\FlightSerachTest\\src\\test\\resources\\drivers\\IEDriverServer.exe");
			driver=new InternetExplorerDriver();
			driver.get(url);
		}
		else try { 
			throw new Exception("Browser is not correct");
		} catch (Exception e) {

			e.printStackTrace();
		} 
	
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	

		return driver;

	}
	
	public void failed() throws IOException
	{
		File srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(srcFile, new File("C:\\salunsx\\eclipse-workspace\\Flight\\src\\test\\resources\\Screenshots\\"+"failshot_"+this.getClass().getName()+"_"+".jpg"));
	}
	
	
	public static void closebrowser()
	{
		driver.close();
	}
		

}
