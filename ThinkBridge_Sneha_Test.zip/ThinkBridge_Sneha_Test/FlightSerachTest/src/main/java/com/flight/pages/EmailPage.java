
package com.flight.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.flight.pageobjects.EmailPageObjects;
import com.flight.utilities.WaitHelper;


public class EmailPage {
	public WebDriver driver;
	public EmailPageObjects emailpageobject;
	public WaitHelper wait;
	public static Properties config;
	public static FileInputStream fis;

	public EmailPage(WebDriver driver)
	{
		this.driver= driver;
		emailpageobject =new EmailPageObjects(driver);
		wait=new WaitHelper(driver);
	}


	public  void createEmailAccount(String email) throws IOException
	{    
		config=new Properties();
		fis=new FileInputStream("C:\\salunsx\\eclipse-workspace\\Flight\\src\\test\\resources\\testdata\\testdata.properties");
		config.load(fis);
   		email =config.getProperty("CreateEmail_mail");
		driver.navigate().to("https://www.sharklasers.com/inbox");
		wait.pause(10000);
		emailpageobject.Username().click();
		emailpageobject.setMailBox().clear();
		emailpageobject.setMailBox().sendKeys(email);
		emailpageobject.setMailBtn().click();

	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	public List<String> getEmails()
	{   
		emailpageobject.inboxTab().click();
		List<String> actualList=new ArrayList<String>();
		List<WebElement> actualVal = emailpageobject.getInboxList();
		for(WebElement ref : actualVal)
		{
			actualList.add(ref.getText());
		}
		return actualList;
	}

	public void verifyEmailRecived()
	{
		String exp_email = "donotreply-dev@jabatalks.com";

		EmailPage emailpage=new EmailPage(driver);
		Iterator<String> it=emailpage.getEmails().iterator();
		List<String> allEmails=emailpage.getEmails();
		wait.pause(20000);
		wait.waitTillListElementsIsVisible(emailpageobject.emailList(), 100000);
		
		if((allEmails.size()>1))
		{
			while(it.hasNext())
			{
				String email=it.next();
				System.out.println(email);
				if(email.equalsIgnoreCase(exp_email)) {
					System.out.println("Email Recieved");
					break;
				}

				else

				{ System.out.println("Email not Recieved");

				}
			}
		

		}
			
	
	}

}
