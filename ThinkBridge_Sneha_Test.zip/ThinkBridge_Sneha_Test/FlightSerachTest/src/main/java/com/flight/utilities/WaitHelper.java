
package com.flight.utilities;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class WaitHelper {
	
WebDriver driver;
	
	public WaitHelper(WebDriver driver) {
		this.driver= driver;
		
		
	}
	
	
	
	public void pause(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
			e.getCause();
			e.getMessage();
			e.printStackTrace();
		}
	}
	
	
	public void implicitWait(int time) {
		driver.manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);	
	}
	
	@SuppressWarnings("deprecation")
	public void waitTillElementIsVisible(WebElement ele, int timeOunt) {
		WebDriverWait wait = new WebDriverWait(driver,timeOunt);
		wait.until(ExpectedConditions.visibilityOf(ele));
		
	}
	@SuppressWarnings("deprecation")
	public void waitTillListElementsIsVisible(List<WebElement> ele, int timeOunt) {
		WebDriverWait wait = new WebDriverWait(driver,timeOunt);
		wait.until(ExpectedConditions.visibilityOfAllElements(ele));
		
	}

}
