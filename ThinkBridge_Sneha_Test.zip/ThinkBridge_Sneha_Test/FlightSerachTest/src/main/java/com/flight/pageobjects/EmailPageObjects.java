
package com.flight.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.flight.pages.EmailPage;


public class EmailPageObjects  {
	WebDriver driver;
	public EmailPageObjects(WebDriver sdriver)
    {
       this.driver=sdriver;
       PageFactory.initElements(driver, this);
    }

	
	@FindBy(how=How.ID,using="inbox-id") WebElement username;
	@FindBy(how=How.XPATH,using="//span[@id='inbox-id']//input[@type='text']") WebElement setMailBox;
	@FindBy(how=How.XPATH,using="//button[contains(text(),'Set')]") WebElement setemailbtn;
	@FindBy(how=How.ID,using="nav-item-inbox") WebElement inboxitemtab;
	@FindBy(how=How.ID,using="email_list") List<WebElement> emaillist;
	@FindBy(how=How.CLASS_NAME,using="td2") List<WebElement> inboxList;
	
	public WebElement Username() {
		return username;
	}
	
	public WebElement setMailBox() {
		return setMailBox;
	}
	public WebElement setMailBtn() {
		return setemailbtn;
	}
	public WebElement inboxTab() {
		return inboxitemtab;
	}
	public List<WebElement> emailList() {
		return emaillist;
	}
	public List<WebElement> getInboxList() {
		return inboxList;
	}
}
