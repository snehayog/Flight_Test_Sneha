
package com.flight.utilities;
import java.io.IOException;

import org.testng.ITestContext;
import org.testng.ITestNGListener;
import org.testng.ITestResult;

import com.flight.base.TestBase;

public class TestListeners extends TestBase implements ITestNGListener {

	private static String getTestMethodName(ITestResult iTestResult) {
		return iTestResult.getMethod().getConstructorOrMethod().getName();
	}


	public void onStart(ITestContext iTestContext) {
		System.out.println("I am in onStart method " + iTestContext.getName());
		iTestContext.setAttribute("WebDriver", this.driver);
	}
	

	public void onTestStart(ITestResult iTestResult) {
		System.out.println("I am in onTestStart method " + getTestMethodName(iTestResult) + " start");
	}

	public void onTestSuccess(ITestResult iTestResult) {
		System.out.println("I am in onTestSuccess method " + getTestMethodName(iTestResult) + " succeed");
		
	}
	
	public void onTestFailure(ITestResult iTestResult) throws IOException {
		System.out.println("I am in onTestFailure method " + getTestMethodName(iTestResult) + " failed");

		//Take  screenshot.
		failed();

		
	}
	public void onTestSkipped(ITestResult iTestResult) {
		System.out.println("I am in onTestSkipped method " + getTestMethodName(iTestResult) + " skipped");
		
	}

}
