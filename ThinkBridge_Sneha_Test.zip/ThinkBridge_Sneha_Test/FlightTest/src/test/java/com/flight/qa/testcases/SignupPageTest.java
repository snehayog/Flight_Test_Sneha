package com.flight.qa.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.flight.qa.base.TestBase;

import com.flight.qa.pages.SignupPage;

public class SignupPageTest extends TestBase {
	SignupPage signup;

	
	public SignupPageTest() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	@BeforeMethod
	public void setup() throws IOException
	{
		initialization();
		
		signup=new SignupPage();
		
	}
	
	
	@Test
	public void signupTest() throws InterruptedException
	{
		signup.CreateEmail();
		signup.signup("Sneha", "Sneha", "snehayog2@aceadd.com");
		signup.VerifyEmail();
		
	}
	
	@AfterMethod
	public void tearDown()
	{
		//driver.quit();
	}
}
