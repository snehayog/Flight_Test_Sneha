package com.flight.qa.pages;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.flight.qa.base.TestBase;

public class SignupPage extends TestBase {

	public SignupPage() throws IOException {
		PageFactory.initElements(driver, this);
	}
@FindBy(xpath="//body/div[1]/div[2]/section[1]/div[1]/div[2]/section[1]/div[1]/div[1]/span[1]")
WebElement langDrpDown;

@FindBy(id="name")
WebElement FullName;

@FindBy(id="orgName")
WebElement OrgName;

@FindBy(id="singUpEmail")
WebElement Email;

@FindBy(xpath="//span[contains(text(),'I agree to the')]")
WebElement chebox;

@FindBy(xpath="//button[contains(text(),'Get Started')]")
WebElement signupbtn;


@FindBy(xpath = "//a[contains(text(),'Edit')]")
WebElement Edit;
@FindBy(xpath = "//input[@id='emailInputModal']")
WebElement EmailInput;
@FindBy(xpath = "//a[@id='emailFormBtn']")
WebElement ConfirmBtn;

public String validateSignupPageTitle()
{
	return driver.getTitle();
}
public void signup(String fn, String orgnm, String email)
{
	driver.get("http://jt-dev.azurewebsites.net/#/SignUp");
	driver.navigate().to("http://jt-dev.azurewebsites.net/#/SignUp");
	FullName.sendKeys(fn);
	OrgName.sendKeys(orgnm);
	Email.sendKeys(email);
	chebox.click();
	signupbtn.click();
	
	//return new HomePage();
}

public void VerifyEmail() {
	driver.navigate().back();
	String exp_email = "donotreply-dev@jabatalks.com";	
	List<String> actualList=new ArrayList<String>();
	List<WebElement> actualVal = driver.findElements(By.xpath("//tbody/tr/td[@Class=\"from\"]"));
	
	for(WebElement ref : actualVal)
	{
	actualList.add(ref.getText());
	}
	Iterator<String> it=actualList.iterator();
	if((actualVal.size()>1))
	{
		while(it.hasNext())
		{
			String email=it.next();
			System.out.println(email);
			if(email.equalsIgnoreCase(exp_email)) {
				System.out.println("Email Recieved");
				break;
			}

			else

			{ System.out.println("Email not Recieved");

			}
		}
	}
	
	
}
public void CreateEmail() {
	
		 driver.navigate().to("https://www.minuteinbox.com/");
		 Edit.click();
		 EmailInput.click();
		 EmailInput.sendKeys("snehayog");
		 ConfirmBtn.click();
	
}

}
